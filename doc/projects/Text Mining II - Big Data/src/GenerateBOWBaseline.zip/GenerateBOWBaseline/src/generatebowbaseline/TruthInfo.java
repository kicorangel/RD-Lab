package generatebowbaseline;

/**
 *
 * @author kico
 */
public class TruthInfo {
    public String Age = "";
    public String Gender = "";
}
