/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package stats;

/**
 *
 * @author kico
 */
public class TruthInfo {
    public String Age = "";
    public String Gender = "";
}
